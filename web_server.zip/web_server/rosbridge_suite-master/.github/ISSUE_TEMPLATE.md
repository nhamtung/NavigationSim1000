<!-- If you have a question about how to use rosbridge, please ask at https://answers.ros.org/ -->


## Expected Behavior


## Actual Behavior


## Steps to Reproduce the Problem

  1.
  1.
  1.

## Specifications

  - ROS Version (`echo $ROS_DISTRO`):
  - OS Version (`grep DISTRIB_CODENAME /etc/lsb-release`):
  - Rosbridge Version (`roscat rosbridge_server package.xml | grep '<version>'`):
  - Twisted Version (`python -c 'import twisted; print twisted.version'`):
