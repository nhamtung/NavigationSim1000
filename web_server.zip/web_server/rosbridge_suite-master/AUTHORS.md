Original Authors
----------------

 * Jonathan Mace (jonathan.c.mace@gmail.com)

Contributors
------------

 * [Jihoon Lee](http://notemywish.com) (jihoonlee.in@gmail.com)
 * [Russell Toris](http://users.wpi.edu/~rctoris/) (rctoris@wpi.edu)
 * Brandon Alexander (baalexander@gmail.com)
 * David Bertram (davidbertram@gmx.de)
 * Matthias Gruhler (matthias.gruhler@ipa.fraunhofer.de)
 * [Matt Vollrath](https://mvollrath.net) (matt@endpoint.com)
